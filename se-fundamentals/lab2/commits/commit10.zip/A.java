public interface A {

    int ae();

    String nn();
}
