public interface I {

    float ff();

    byte oo();
}
