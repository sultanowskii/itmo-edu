public class I extends null {

    float ff();

    byte oo();
}
