public class D extends null implements I, A {

    private double g = 100.500;

    private double d = 100.500;

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public float ff() {
        return 3.14;
    }

    public byte oo() {
        return 1;
    }

    public int ae() {
        return 9;
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public Object pp() {
        return this;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int cc() {
        return 13;
    }

    public void bb() {
        System.out.println(42);
    }

    public Object rr() {
        return null;
    }

    public double ad() {
        return 9.11;
    }

    public void ab() {
        System.out.println("\n");
    }
}
