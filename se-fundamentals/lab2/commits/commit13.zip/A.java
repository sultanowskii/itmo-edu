public class A extends null {

    int ae();

    String nn();
}
