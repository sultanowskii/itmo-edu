public class C extends null {

    java.util.Random mm();

    long ac();
}
