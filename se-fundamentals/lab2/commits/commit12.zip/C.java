public interface C {

    java.util.Random mm();

    long ac();
}
