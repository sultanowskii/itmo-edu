# Как запустить часть №N?

```
cd partN
python script.py
```
